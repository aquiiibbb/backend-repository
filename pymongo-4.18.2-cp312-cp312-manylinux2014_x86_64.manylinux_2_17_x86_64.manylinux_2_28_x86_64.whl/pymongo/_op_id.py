# Copyright 2026-present MongoDB, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License"); you
# may not use this file except in compliance with the License.  You
# may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied.  See the License for the specific language governing
# permissions and limitations under the License.

"""Internal helpers for the APM operation id.

The retryable read/write logic sets OP_ID if APM/logging is enabled for the duration of each attempt so
that every attempt of one logical operation publishes the same operation_id.
Commands run outside that scope (handshake, auth, killCursors, pinned-cursor
getMores) read the default None and fall back to their request_id.
"""

from __future__ import annotations

from contextlib import AbstractContextManager
from contextvars import ContextVar
from typing import Any, Optional

OP_ID: ContextVar[Optional[int]] = ContextVar("OP_ID", default=None)


def reset() -> None:
    OP_ID.set(None)


class _OpIdContext(AbstractContextManager[Any]):
    """Set OP_ID for the duration of a with block."""

    def __init__(self, op_id: Optional[int]):
        self._op_id = op_id

    def __enter__(self) -> None:
        self._token = OP_ID.set(self._op_id)

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        OP_ID.reset(self._token)
